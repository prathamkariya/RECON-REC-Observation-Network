# DAU Agent Skills — Hackathon Engineering Router

## Mission
Build high-quality hackathon and project software quickly without sacrificing correctness, UX, security, or deployability. Use the smallest set of skills that materially improves the current task. Do not invoke skills as a checklist.

## Skill discovery
Skills live in `.agents/skills/<skill-name>/SKILL.md`. Only use skills that actually exist in this project. Load a skill when the task clearly matches its description or when the workflow below calls for it. Preserve bundled `scripts/`, `references/`, and `assets/`; they are part of the skill.

## Primary workflow
1. Understand the request and inspect the repository before changing code.
2. For non-trivial work, clarify goals/constraints and make a short plan.
3. Reuse existing architecture/components before adding abstractions.
4. Implement incrementally. Prefer small, reversible changes.
5. Verify with tests, type checks, builds, browser checks, or targeted commands appropriate to the change.
6. Review security, performance, UX, and deployment implications when relevant.
7. Report what changed, what was verified, and any remaining uncertainty.

## Routing

### Planning / product
Use: `brainstorming`, `idea-refine`, `grill-me`, `research`, `interview-me` (if available), `spec-driven-development`, `to-spec`, `planning-and-task-breakdown`, `writing-plans`, `constraint-driven-development`, `domain-modeling`, `codebase-design`, `prototype`.

### Implementation / architecture
Use: `implement`, `incremental-implementation`, `api-and-interface-design`, `context-engineering`, `source-driven-development`, `doubt-driven-development`, `lean-build`, `code-simplification`, `safe-refactor`, `surgical-patch`, `improve-codebase-architecture`.

### Frontend / UI / UX
Keep frontend skills available and choose only those relevant to the current UI: `frontend-ui-engineering`, `frontend-design`, `react-best-practices`, `composition-patterns`, `ui-styling`, `ui-ux-pro-max`, `design-system`, `web-design-guidelines`, `taste-skill`, `design-taste-frontend-v1`, `gpt-taste`, `stitch-design-taste`, `high-end-visual-design`, `image-to-code`, `redesign-existing-projects`, `brand`, `brand-guidelines`, `brandkit`, `banner-design`, `slides`, `algorithmic-art`, `canvas-design`, `industrial-brutalist-ui`, `minimalist-ui`, `imagegen-frontend-web`, `imagegen-frontend-mobile`, `theme-factory`, `vercel-react-view-transitions`, `web-artifacts-builder`, `artifacts-builder`.

For normal React/Next.js work, prefer `react-best-practices` + `composition-patterns` + `frontend-ui-engineering`; add visual-design skills only when visual quality is a real requirement.

### Testing / debugging
Use: `tdd` or `test-driven-development` for test-first work; `systematic-debugging`, `diagnosing-bugs`, `debugging-and-error-recovery` for failures; `browser-testing-with-devtools`, `webapp-testing`, and `agent-browser` for browser behavior; `verification-before-completion` and `verify-and-stop` before claiming completion.

### Quality / security / performance
Use: `code-review-and-quality`, `karpathy-guidelines`, `code-simplification`, `performance-optimization`, `security-and-hardening`, `observability-and-instrumentation`.

### Git / collaboration
Use: `git-workflow-and-versioning`, `using-git-worktrees`, `requesting-code-review`, `receiving-code-review`, `executing-plans`, `dispatching-parallel-agents`, `subagent-driven-development`, `finishing-a-development-branch`, `resolving-merge-conflicts`.

### CI / deployment
Use: `ci-cd-and-automation`, `shipping-and-launch`, `deploy-to-vercel`, `vercel-optimize`, `vercel-cli-with-tokens`.

### AI / agents / MCP
Use: `mcp-builder`, `skill-creator`, `context-engineering`, `langsmith-fetch` when the task involves MCP, agent tooling, custom skills, LangChain/LangGraph traces, or agent context.

### Documents / deliverables
Use `docx`, `pdf`, `pptx`, `xlsx`, `doc-coauthoring`, and `slides` when the deliverable requires those formats.

### Discovery / optional behavior
`find-skills` is opt-in discovery. `i-have-adhd` is opt-in response/task-structuring support. Do not invoke either merely because they exist.

## Important exclusions
Do NOT install or use `using-superpowers`; it is an always-on competing master router. This project uses this `AGENTS.md` as the central router. Do not install catalog-only or unrelated utility skills merely because they exist upstream.

## Hackathon mode
When the user says hackathon/SIH/competition/demo: prioritize scope control, fast validation, a working vertical slice, polished frontend, reliable demo flow, clear architecture, and deployment. Avoid speculative abstractions. Prefer `prototype` for uncertain ideas, `lean-build` for high overbuilding risk, and `verification-before-completion` before demo claims.

## Engineering principles
- Surface assumptions instead of silently inventing requirements.
- Stop and investigate when evidence contradicts expectations.
- Prefer simple solutions over clever architecture.
- Preserve existing behavior unless the task explicitly changes it.
- Never claim tests/builds/deployment succeeded without actually verifying them.
- Security and privacy are part of correctness.
- Use official documentation when APIs/framework behavior is uncertain.
